<?php
    echo "page 404";