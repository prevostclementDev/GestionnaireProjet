<?php 

    echo "hello, get out please ;)";