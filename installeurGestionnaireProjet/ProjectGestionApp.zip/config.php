<?php

    /* SITE URL */
    define("uri", '/__site/__fromscratch/GestionnaireProjet/app/');
    
    define("baseUrl", '<base href="'.uri.'">');

    /* BDD CONNECTION */

    define('dbhost',"localhost");
    define('dbname','gestionnaireprojet');
    define('dbuser','root');
    define('dbpassword','');